from pathlib import Path
import subprocess,json
ROOT=Path(__file__).resolve().parent
files=['Personal_Footage_Review.mp4','Route_Motion_Preview.mp4','Contact_Card_Preview.mp4']
frames=[]
for name in files:
 d=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_entries','stream=codec_type,nb_frames','-of','json',str(ROOT/name)]))
 frames.append(int(next(s for s in d['streams'] if s['codec_type']=='video')['nb_frames']))
n=sum(frames);duration=n/24
out=ROOT/'Alexander_Leiar_V3_Sequence_Review.mp4'
cmd=['ffmpeg','-v','warning','-y']
for name in files:cmd+=['-i',str(ROOT/name)]
cmd+=['-filter_complex_threads','1','-filter_complex',f'[0:v][1:v][2:v]concat=n=3:v=1:a=0,format=yuv420p[v];[0:a]apad,atrim=duration={duration}[a]','-map','[v]','-map','[a]','-frames:v',str(n),'-t',str(duration),'-c:v','libx264','-preset','fast','-crf','19','-maxrate','5000k','-bufsize','10000k','-threads','2','-c:a','aac','-b:a','192k','-ar','48000','-movflags','+faststart','-metadata','title=Alexander Leiar V3 — selected sequence review, not final narrative',str(out)]
subprocess.run(cmd,check=True)
subprocess.run(['ffmpeg','-v','error','-xerror','-i',str(out),'-f','null','-'],check=True)
print('Sequence review decoded:',n,'frames',duration,'seconds',out.stat().st_size,'bytes',flush=True)

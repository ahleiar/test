from pathlib import Path
import json,re
ROOT=Path(__file__).resolve().parent
ACTS=[
('Act 1 — Introduction and bottom line','Start on camera. Cut to Alexander’s own South African wildlife or a licensed Cape Town establishing shot.',[
('A1-01','One word I would use to describe myself is cosmopolitan—which in Greek means a citizen of the world.','R01A','Existing audio reference: 2.1–8.8s; new on-camera image is required.'),
('A1-02','Hi, I’m Alexander Leiar, a third-year business student at the University of Arizona’s Eller College of Management. For leaders in commercial real estate and entrepreneurship, I bring an international perspective, the ability to adapt, and a genuine interest in building relationships.','R01B','Not spoken in the supplied MP4; reserve a recording slot.'),
('A1-03','My story is a little different from most. I was born in Portugal and grew up in South Africa, where I was exposed to different cultures, people, and ways of life from an early age. That experience taught me to stay open-minded and make the most of new situations.','R02-OPTIONAL','Existing audio reference: 32.5–47s. Caption source omits the end of “from an early age”; check the actual clean recording before final conform.')]),
('Act 2 — Sports and travel','Keep Alexander’s real water polo and wildlife. Use licensed travel establishes for generic phone clips. Add a restrained map of Africa, Europe and Asia.',[
('A2-01','Growing up, sports were a big part of my life. I played rugby and water polo and swam competitively. Those experiences taught me discipline, resilience, and how to perform both as part of a team and on my own.','R02-OPTIONAL','Existing audio reference: 48.5–62.2s. Retain authentic water polo. Rugby/swimming footage has not been supplied.'),
('A2-02','Traveling across Africa, Europe, and Asia also pushed me outside my comfort zone. Each place introduced me to new perspectives and helped me become more comfortable connecting with people from different backgrounds.','R02-OPTIONAL','Existing audio reference: 62.5–75.2s. The old take adds “Moreover”; remove only after checking the word boundary.')]),
('Act 3 — Professional experience','Animate a real map route: South Africa → Ireland → St. Louis. Add each employer’s name over relevant licensed footage. Keep the sales result tied to Abstrakt.',[
('A3-01','That adaptability has carried into my professional experiences. At Fine & Rare Wines in South Africa, I gained exposure to supply chain operations and client service. At DM Financial in Ireland, I worked with financial statements, helped with payroll and supported the management accounts team.','R03A','Existing audio reference: 76–94s. Opening wording differs (“And that adaptability right there…”). Record the opening sentence for exact wording; remaining wording is a reference pending audio review.'),
('A3-02','Most recently, at Abstrakt Marketing Group in St. Louis, I stepped into a fast-paced sales environment and connected with business leaders to identify opportunities. There, I generated 10 qualified appointments representing roughly $250,000 in potential pipeline revenue.','R03-OPTIONAL','Existing audio reference: 94.6–110.7s. Preserve “potential”; never present this as closed revenue.'),
('A3-03','Each experience challenged me in a different way, but all three taught me the importance of getting comfortable being uncomfortable, building trust, and being willing to learn.','R03B','Record this full sentence. The old take differs and includes the repeated “uncomfortable” wording.')]),
('Act 4 — What I bring','Return to Alexander on camera. Intercut real campus and Arizona water polo. Animate “Adaptability”, “Relationships”, and “Global Perspective”, one phrase at a time.',[
('A4-01','Today, I bring those lessons with me to Eller and to the Arizona water polo team. Balancing academics, athletics, and professional opportunities has strengthened my time management and commitment to the people who count on me.','R04','Existing audio reference: 123.5–136.6s; wording differs slightly. New on-camera recording slot covers both Act 4 paragraphs.'),
('A4-02','For a real estate team or growing business, I bring a willingness to learn, a perspective shaped by international experiences, and the communication skills to connect with different people. I’m excited by opportunities where I can help build relationships, solve problems, and contribute to a team.','R04','Existing audio reference: 136.6–153s; “help build” differs from the old take. Use the new take for exact script wording.')]),
('Act 5 — Closing','Alexander speaks to camera. End with his name, actual LinkedIn profile and email. No stock actor substitutes for Alexander.',[
('A5-01','Looking ahead, I want to learn from experienced professionals, explore commercial real estate, and eventually start a business of my own.','R05','Existing audio reference: 153.9–161s. New on-camera image is required.'),
('A5-02','If you’re looking for someone who is curious, adaptable, and ready to contribute, I’d love to connect through LinkedIn or email. Thank you for taking the time to learn a little about me.','R05','Existing audio reference: 161–169.8s; the new LinkedIn/email call to action is not in the old recording. Record this take.')])]
contacts={'name':'Alexander Leiar','email':'alexleiar@gmail.com','linkedin':'https://www.linkedin.com/in/alex-leiar-395b1a415/'}
actrows=[];plain=[];md=['# Alexander Leiar — approved five-act script','', 'Source: the script supplied in this conversation. Capitalization and the spelling of Greek/LinkedIn are normalized. No new biographical claims have been added.','']
coverage=['# Recording coverage and pickups','', 'Time references point into the supplied 2:52 MP4 and are approximate references from its visible captions, not a word-aligned transcript. The new script controls the final wording. Clearly marked review slots are intentional; they are not final film frames.','', '| Line | Recording slot | Existing material / required action |','|---|---|---|']
for title,visual,lines in ACTS:
 md += ['## '+title,'','**Visual:** '+visual,''];plain += [title.upper(),'']
 rows=[]
 for key,text,recording,note in lines:
  md += [text,''];plain += [text,''];coverage += [f'| {key} | {recording} | {note} |']
  rows.append(dict(id=key,text=text,recording_slot=recording,coverage=note,word_count=len(re.findall(r"\b[\w’'-]+\b",text))))
 actrows.append(dict(title=title,visual=visual,lines=rows))
md += ['## Closing card','', 'Alexander Leiar','',contacts['email'],'',contacts['linkedin'],'']
(ROOT/'SCRIPT.md').write_text('\n'.join(md))
(ROOT/'TELEPROMPTER.txt').write_text('\n'.join(plain))
(ROOT/'RECORDING_COVERAGE.md').write_text('\n'.join(coverage)+'\n')
words=sum(line['word_count'] for act in actrows for line in act['lines'])
(ROOT/'script.json').write_text(json.dumps({'contacts':contacts,'acts':actrows,'words':words,'estimated_spoken_duration_seconds_at_155_wpm':round(words/155*60),'status':'script approved; new recordings and stock media pending'},indent=2,ensure_ascii=False))
print('Saved complete script:',words,'words; approximately',round(words/155*60),'seconds of speech at 155 wpm.')

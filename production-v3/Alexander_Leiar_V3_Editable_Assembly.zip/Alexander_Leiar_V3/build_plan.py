from pathlib import Path
import json,re,csv
ROOT=Path(__file__).resolve().parent
script=json.loads((ROOT/'script.json').read_text())
STOCK=[
('ST01','A1-01','Cape Town establishing aerial','cape town table mountain aerial','Cape Town skyline / Table Mountain visible; calm camera; natural light. Optional: original wildlife already covers this beat.'),
('ST02','A1-03','Portugal establishing shot','lisbon portugal city aerial','Recognizable Portugal; a short 1–2 second establishing insert, not a substitute for Alexander’s own childhood footage.'),
('ST03','A2-02','Europe travel establishing','london thames westminster aerial','Replace generic vertical London/night phone coverage with stable landscape footage. A landmark must identify the correct location.'),
('ST04','A2-02','Asia travel establishing','asia city skyline travel','Use as illustrative regional coverage; do not assert a specific visited city without Alexander confirming it.'),
('ST05','A3-01','Wine logistics / distribution','wine warehouse logistics boxes','Use as illustration of supply chain/client service; do not imply stock workers are Fine & Rare Wines employees.'),
('ST06','A3-01','Ireland establishing','dublin ireland aerial river','Replace phone road/airport shots with relevant landscape establishing footage.'),
('ST07','A3-01','Financial operations detail','financial spreadsheet accounting office','Modern, plausible financial work; anonymous closeups and no readable private data or fake employer logos. Replace the photographed presentation slide.'),
('ST08','A3-02','St. Louis establishing','st louis missouri gateway arch aerial','Real St. Louis skyline/Arch; no generic city presented as St. Louis.'),
('ST09','A3-02','Business development','business meeting conversation office','Illustrative relationship-building, natural interactions, no fake identity or claim that Alexander is the stock actor.'),
('ST10','A3-03','Irish coastal breathing room','ireland cliffs coast drone','Replace generic phone cliff footage. Subtle movement, neutral sky, horizon steady.'),
('ST11','A4-02','Commercial real estate establishing','modern commercial building exterior city','Replace generic phone city/airplane/sunset B-roll. Specific properties are illustrative, never claimed as clients.'),
('ST12','A5-01','Entrepreneurship / commercial space','commercial office workspace architecture','One short supporting insert; finish on Alexander’s real camera recording and contact card.')]
retained=[
{'id':'OWN-SA-01','source':'original MP4 33.3–35.8s','content':'Elephant/safari','keep':True},
{'id':'OWN-SA-02','source':'original MP4 42.0–44.1s','content':'Giraffes','keep':True},
{'id':'OWN-SA-03','source':'original MP4 45.3–47.6s','content':'Lion','keep':True},
{'id':'OWN-SPORT-SA','source':'original MP4 53.2–61.1s','content':'South African water polo','keep':True},
{'id':'OWN-SPORT-AZ','source':'original MP4 129.1–135.2s','content':'Arizona water polo','keep':True},
{'id':'OWN-PORTRAIT','source':'original MP4 74.7–75.7s','content':'Alexander in front of the clock','keep':True,'use':'brief authentic personal insert; no stock person replacement'},
{'id':'OWN-CAMPUS','source':'original MP4 12.1–29.5s, excluding overlays','content':'Actual university campus coverage','keep':True,'use':'short relevant inserts; no repetitive long campus holds'}]
rows=[]
for key,line,subject,query,note in STOCK:
 rows.append(dict(id=key,script_line=line,subject=subject,query=query,notes=note,status='awaiting stock-site access / no clip selected',provider=None,clip_url=None,creator=None,license_url=None,downloaded=False,search_url='https://www.pexels.com/search/videos/'+query.replace(' ','%20')+'/',fallback_search_url='https://mixkit.co/free-stock-video/'))
(ROOT/'stock_manifest.json').write_text(json.dumps(rows,indent=2))
(ROOT/'retained_media.json').write_text(json.dumps(retained,indent=2))
md=['# Five-act picture plan','', 'The supplied script is the final wording reference. Timing remains provisional until the new recordings arrive. The review will show clearly named recording slots; final frames will not contain those slot labels.','', '| Act | Camera and personal material | Stock replacement | Motion design |','|---|---|---|---|',
'| 1 | Start on Alexander, then original elephant/giraffe/lion footage. Keep real personal inserts. | Optional Cape Town / Portugal establishing shots. | Single kinetic “COSMOPOLITAN” reveal; a small name introduction. |',
'| 2 | Preserve both South African and Arizona water polo. Keep actual rugby/swimming if supplied later. | Replace generic phone travel clips with licensed, landscape travel coverage. | Africa / Europe / Asia map; brief discipline/resilience keywords keyed to speech. |',
'| 3 | Use actual internship photo only if it adds personal context and is clear enough. | Replace presentation photo, phone road/airport/city clips with wine logistics, financial operations, real St. Louis and business-development B-roll. | South Africa → Ireland → St. Louis route; clean employer identifiers; 10 appointments / approximately $250K **potential** pipeline. |',
'| 4 | Return to Alexander’s camera recording, actual campus and actual Arizona water polo. | A few relevant commercial-space inserts as needed. | Adaptability → Relationships → Global Perspective, one phrase at a time. |',
'| 5 | Alexander to camera; authentic closing. | Optional single commercial-space insert before returning to camera. | Full-frame name/email/LinkedIn end card; no border or framed panel. |','',
'## Retained original footage','']
md += [f"- **{r['id']}** — {r['content']}; {r['source']}." for r in retained]
md += ['', '## Stock shot list','', '| ID | Script line | Subject | Selection note |','|---|---|---|']
md += [f"| {r['id']} | {r['script_line']} | {r['subject']} | {r['notes']} |" for r in rows]
md += ['', '## Stock status','', 'Pexels and Mixkit currently return proxy HTTP 403 in this running environment. Access domains are saved in the environment configuration draft; draft saving does not apply the runtime policy. No stock clips have been downloaded or claimed as licensed. After access is active, select actual clips, verify each clip’s free commercial-use license, record the creator/source/license URLs, and replace the assigned slot. Do not treat a search result as a cleared asset.','', 'Prefer landscape 1920×1080 or higher, natural camera movement, stable horizons and consistent light. Do not use editorial-only material, retain watermarks, or invent internship/property relationships. Supporting stock is illustrative; Alexander’s own footage establishes his identity and experience.']
(ROOT/'PICTURE_PLAN.md').write_text('\n'.join(md)+'\n')
recordings=[
('R01A','Opening','A1-01','Record the “One word…” opening directly to camera. We then cut to your own wildlife.'),
('R01B','Introduction and bottom line','A1-02','Record the complete “Hi, I’m Alexander…” paragraph. This audio is absent from the old video.'),
('R03A','Professional-experience pickup','A3-01','Record the exact first sentence, “That adaptability has carried into my professional experiences.” Ideally record the whole paragraph for a seamless match.'),
('R03B','Reflection pickup','A3-03','Record the full corrected sentence, including “getting comfortable being uncomfortable”.'),
('R04','What I bring','A4-01 + A4-02','Record both Act 4 paragraphs to camera. They are intercut with your real campus and water polo.'),
('R05','Closing','A5-01 + A5-02','Record both closing paragraphs, including the new “through LinkedIn or email” call to action.')]
guide=['# New recording slots','', 'Record each named section as a separate clip. Match the wording in `SCRIPT.md`. The edit has named placeholders for these recordings; no stock actor or synthetic voice is being substituted.','', '| Filename | Section | Lines | Direction |','|---|---|---|']
guide += [f'| `{key}.mp4` | {title} | {lines} | {note} |' for key,title,lines,note in recordings]
guide += ['', '## Capture','', '- Film horizontally in 4K or 1080p, at 24 or 30 fps, with the lens at eye level. Keep some space around your head and shoulders for reframing.', '- Use a quiet room and soft window light. Avoid a bright window behind you; lock focus and exposure if the phone allows it.', '- Leave about three seconds before and after each take. Keep the original files; avoid sending a re-compressed messaging-app copy.', '- For the cleanest script match, you may record Acts 2 and 3 as voice-only pickups too. The existing track is a reference, not a word-verified final narration.','', '## Closing details','',script['contacts']['email'],'',script['contacts']['linkedin'],'', 'The next review will show recording-slot labels. They disappear when the actual takes are conformed.']
(ROOT/'RECORDING_GUIDE.md').write_text('\n'.join(guide)+'\n')
# Provisional editor timeline: exact script line IDs, roles, and external-media slots.
assembly=[];cursor=0
for act in script['acts']:
 for line in act['lines']:
  dur=round(line['word_count']/155*60,2)
  camera=line['recording_slot'] in {'R01A','R01B','R04','R05'}
  stock=[r['id'] for r in rows if r['script_line']==line['id']]
  assembly.append(dict(line_id=line['id'],start=round(cursor,2),duration=dur,text=line['text'],recording_slot=line['recording_slot'],camera_slot=camera,review_marker=('RECORDING REQUIRED — '+line['recording_slot']) if camera else None,voice_status='new recording pending' if camera or line['recording_slot'] in {'R03A','R03B'} else 'existing audio reference; verify exact wording',stock_slots=stock))
  cursor+=dur
(ROOT/'assembly.json').write_text(json.dumps({'version':3,'status':'offline assembly; recording slots intentionally marked; stock pending','fps':24,'contacts':script['contacts'],'timing_basis':'155 words/minute planning estimate, not final audio timing','lines':assembly,'end_card':{'start':round(cursor,2),'duration':5,'file':'Contact_Card_Preview.mp4'},'estimated_duration':round(cursor+5,2)},indent=2,ensure_ascii=False))
print('Saved five-act assembly, retained-media list, 12 stock slots and six recording-slot instructions.')

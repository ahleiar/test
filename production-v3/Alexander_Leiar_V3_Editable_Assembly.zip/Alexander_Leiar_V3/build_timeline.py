from pathlib import Path
import sys,json,shutil,subprocess,math
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT.parent/'vendor'))
import opentimelineio as otio
FPS=24
MEDIA=ROOT/'Media';OWN=MEDIA/'Own';OWN.mkdir(parents=True,exist_ok=True)
SLOTS=MEDIA/'Slots';SLOTS.mkdir(exist_ok=True)
STOCK=MEDIA/'Stock_Pending';STOCK.mkdir(exist_ok=True)
from PIL import Image,ImageDraw,ImageFont
FONT='/usr/share/fonts/openai-sans/OpenAISans-Bold.woff2';REG='/usr/share/fonts/openai-sans/OpenAISans-Medium.woff2'
script=json.loads((ROOT/'script.json').read_text());assembly=json.loads((ROOT/'assembly.json').read_text());manifest=json.loads((ROOT/'stock_manifest.json').read_text())
shutil.copy2('/workspace/video-polish/source.mp4',MEDIA/'Original_Draft.mp4')
for name in ['Route_Motion_Preview.mp4','Travel_Map_Preview.mp4','Contact_Card_Preview.mp4']:shutil.copy2(ROOT/name,MEDIA/name)
for p in (ROOT/'recording_slots').glob('*.png'):shutil.copy2(p,SLOTS/p.name)
own_files={'Wildlife_A.mp4':ROOT/'retained_work/renders/00.mp4','Wildlife_B.mp4':ROOT/'retained_work/renders/01.mp4','Wildlife_Lion.mp4':ROOT/'retained_work/renders/02.mp4','Waterpolo_SA_A.mp4':ROOT/'retained_work/renders/03.mp4','Waterpolo_AZ_A.mp4':ROOT/'retained_work/renders/04.mp4','Waterpolo_SA_B.mp4':ROOT/'retained_work/renders/05.mp4','Waterpolo_AZ_B.mp4':ROOT/'retained_work/renders/06.mp4','Waterpolo_SA_C.mp4':ROOT/'retained_work/renders/07.mp4','Campus_A.mp4':ROOT.parent/'renders/41.mp4','Campus_B.mp4':ROOT.parent/'renders/42.mp4','Personal_Insert.mp4':ROOT.parent/'renders/02.mp4'}
for name,p in own_files.items():shutil.copy2(p,OWN/name)
# Visible placeholders, not purported stock media.
for stock in manifest:
 im=Image.new('RGB',(1920,1080),'#070a0e');d=ImageDraw.Draw(im)
 d.text((100,90),'STOCK SHOT REQUIRED / '+stock['id'],font=ImageFont.truetype(FONT,36),fill='#d0ff35')
 d.text((96,200),stock['subject'].upper(),font=ImageFont.truetype(FONT,65),fill='#fafcf8')
 y=360;buf='';lines=[];ft=ImageFont.truetype(REG,38)
 for word in stock['notes'].split():
  candidate=(buf+' '+word).strip()
  if d.textlength(candidate,font=ft)>1680 and buf:lines.append(buf);buf=word
  else:buf=candidate
 if buf:lines.append(buf)
 for line in lines:d.text((102,y),line,font=ft,fill='#d5dce1');y+=58
 d.text((102,1004),'TEMPORARY REVIEW SLOT / NO STOCK CLIP DOWNLOADED OR LICENSED YET',font=ImageFont.truetype(REG,24),fill='#8d9aa4')
 im.save(STOCK/f"{stock['id']}.png")

def rt(frames):return otio.opentime.RationalTime(round(frames),FPS)
def tr(start,duration):return otio.opentime.TimeRange(rt(start),rt(duration))
def duration(path):
 d=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_entries','stream=nb_frames','-show_entries','format=duration','-of','json',str(path)]))
 streams=d.get('streams',[])
 if streams and streams[0].get('nb_frames','N/A')!='N/A':return int(streams[0]['nb_frames'])
 return round(float(d['format']['duration'])*FPS)
for p in ROOT.glob('Act4_*.mov'):shutil.copy2(p,MEDIA/p.name)
DURS={str(p.relative_to(ROOT)):duration(p) for p in list(MEDIA.rglob('*.mp4'))+list(MEDIA.rglob('*.mov'))}

def refclip(name,path,frames,start=0,metadata=None):
 frames=round(frames);start=round(start);full=DURS.get(path,max(frames+start,10000))
 mr=otio.schema.ExternalReference(target_url=path,available_range=tr(0,full),metadata={'still_image':path.endswith('.png')})
 return otio.schema.Clip(name=name,media_reference=mr,source_range=tr(start,frames),metadata=metadata or {})
def pending_audio(name,n,reason):
 c=otio.schema.Clip(name=name,media_reference=otio.schema.MissingReference(name=reason),source_range=tr(0,n),metadata={'recording_required':True,'reason':reason})
 c.markers.append(otio.schema.Marker(name=reason,marked_range=tr(0,n),color=otio.schema.MarkerColor.RED))
 return c

# Actual supplied audio references; exact wording still requires final review.
AUDIO={'A1-01':(2.1,8.8),'A1-03':(32.5,47.5),'A2-01':(48.5,62.2),'A2-02':(62.5,75.2),'A3-02':(94.6,110.7)}
video=otio.schema.Track(name='Picture — approved personal media + marked recording/stock slots',kind=otio.schema.TrackKind.Video)
audio=otio.schema.Track(name='REFERENCE AUDIO / new takes required where marked',kind=otio.schema.TrackKind.Audio)
timeline=otio.schema.Timeline(name='Alexander Leiar — Five-act offline assembly V3',tracks=[video,audio],global_start_time=rt(0),metadata={'status':'NOT A FINISHED FILM — recording and stock placeholders intentionally visible','script':'SCRIPT.md','contacts':script['contacts'],'project_resolution':'1920x1080','fps':24,'stock_status':'not downloaded; all stock slots explicit','voice_status':'existing audio references, not a word-verified final performance'})
# A piece is a linked 1080p personal clip, a rendered map, a camera slate, or an explicit stock slate.
PLAN={
'A1-01':[('R01A',99)],'A1-02':[('R01B',99)],
'A1-03':[('Wildlife_A.mp4',2.1),('Wildlife_B.mp4',2),('Wildlife_Lion.mp4',1.9),('Personal_Insert.mp4',.8),('ST02',3.5),('Wildlife_A.mp4',2.1),('Wildlife_B.mp4',2),('Wildlife_Lion.mp4',1.9)],
'A2-01':[('Waterpolo_SA_A.mp4',2.9),('Waterpolo_AZ_A.mp4',2.8),('Waterpolo_SA_B.mp4',2.9),('Waterpolo_AZ_B.mp4',2.6),('Waterpolo_SA_C.mp4',2.4)],
'A2-02':[('ST03',3.2),('ST04',3.2),('Travel_Map_Preview.mp4',6.3)],
'A3-01':[('Route_Motion_Preview.mp4',2.9),('ST05',4.5),('ST06',2),('ST07',99)],
'A3-02':[('ST08',4),('ST09',4),('ST11',3),('ST08',99)],
'A3-03':[('ST10',99)],
'A4-01':[('R04',3.2),('Campus_A.mp4',2.5),('Waterpolo_AZ_A.mp4',2.8),('R04',99)],
'A4-02':[('R04',3.2),('ST11',3.2),('R04',99)],
'A5-01':[('R05',99)],'A5-02':[('R05',99)]}
marker_report=[]
for row in assembly['lines']:
 key=row['line_id'];planned=round(row['duration']*FPS)
 if key in AUDIO:planned=max(planned,round((AUDIO[key][1]-AUDIO[key][0])*FPS))
 start_frames=round(video.duration().value);left=planned;pieces=PLAN[key]
 for index,(resource,seconds) in enumerate(pieces):
  n=min(left,round(seconds*FPS))
  if n<=0:break
  if resource.startswith('ST'):
   path=f'Media/Stock_Pending/{resource}.png';kind='stock_required';name=f'{key} / {resource} / STOCK REQUIRED'
  elif resource.startswith('R') and not resource.endswith('.mp4'):
   path=f'Media/Slots/{resource}.png';kind='recording_required';name=f'{key} / {resource} / RECORDING REQUIRED'
  elif resource in own_files:
   path=f'Media/Own/{resource}';kind='retained_personal';name=f'{key} / {resource}'
  else:
   path='Media/'+resource;kind='rendered_motion';name=f'{key} / {resource}'
  if path in DURS:n=min(n,DURS[path])
  clip=refclip(name,path,n,metadata={'script_line_id':key,'role':kind,'script_text':row['text']})
  if kind.endswith('required'):clip.markers.append(otio.schema.Marker(name=name,marked_range=tr(0,n),color=otio.schema.MarkerColor.ORANGE if kind=='stock_required' else otio.schema.MarkerColor.RED))
  video.append(clip);left-=n
 if left:
  # Fill remaining planning time with the final slate, or a clearly marked current section slate.
  resource=pieces[-1][0]
  if resource.startswith('R'):path=f'Media/Slots/{resource}.png'
  elif resource.startswith('ST'):path=f'Media/Stock_Pending/{resource}.png'
  else:path=f'Media/Slots/{row["recording_slot"]}.png' if (SLOTS/f'{row["recording_slot"]}.png').exists() else 'Media/Stock_Pending/ST01.png'
  video.append(refclip(f'{key} / REVIEW HOLD — replace with selected take',path,left,metadata={'script_line_id':key,'review_hold':True}))
 if key in AUDIO:
  a,b=AUDIO[key];count=round((b-a)*FPS)
  audio.append(refclip('REFERENCE VO / '+key,'Media/Original_Draft.mp4',count,start=round(a*FPS),metadata={'script_line_id':key,'reference_only':True,'verify_wording':True}))
  if count<planned:audio.append(otio.schema.Gap(name=key+' / reference tail',source_range=tr(0,planned-count)))
 else:audio.append(pending_audio(key+' / '+row['recording_slot'],planned,'New recording required: '+row['recording_slot']))
 timeline.tracks.markers.append(otio.schema.Marker(name=key+' / '+row['recording_slot'],marked_range=tr(start_frames,planned),color=otio.schema.MarkerColor.GREEN,metadata={'script_text':row['text']}))
 marker_report.append({'line':key,'start':start_frames/FPS,'duration':planned/FPS,'recording_slot':row['recording_slot'],'stock_slots':row['stock_slots']})
video.append(refclip('Final contact card — actual supplied email and LinkedIn','Media/Contact_Card_Preview.mp4',DURS['Media/Contact_Card_Preview.mp4']))
audio.append(otio.schema.Gap(name='Contact-card hold',source_range=tr(0,DURS['Media/Contact_Card_Preview.mp4'])))
assert video.duration()==audio.duration()
overlay=otio.schema.Track(name='Act 4 phrase animations — retime after new recordings',kind=otio.schema.TrackKind.Video)
line_starts={m['line']:m['start'] for m in marker_report}
entries=[(line_starts['A4-01']+3,'Adaptability'),(line_starts['A4-02']+3,'Relationships'),(line_starts['A4-02']+7,'Global_Perspective')]
for when,label in entries:
 target=round(when*FPS);gap=target-round(overlay.duration().value)
 if gap>0:overlay.append(otio.schema.Gap(source_range=tr(0,gap)))
 overlay.append(refclip('Act 4 / '+label,'Media/Act4_'+label+'.mov',3*FPS,metadata={'retime_after_recording':True,'alpha_overlay':True}))
tail=round(video.duration().value-overlay.duration().value)
if tail>0:overlay.append(otio.schema.Gap(source_range=tr(0,tail)))
timeline.tracks.append(overlay)
out=ROOT/'Alexander_Leiar_V3.otio';otio.adapters.write_to_file(timeline,str(out))
loaded=otio.adapters.read_from_file(str(out))
missing=[];pending=[]
for clip in loaded.find_clips():
 mr=clip.media_reference
 if isinstance(mr,otio.schema.ExternalReference):
  if not (ROOT/mr.target_url).is_file():missing.append(mr.target_url)
  if mr.target_url in DURS:
   assert clip.source_range.end_time_exclusive().value<=DURS[mr.target_url]+.01,(clip.name,clip.source_range)
 else:pending.append(clip.name)
assert not missing,missing
report={'status':'validated offline assembly, not a final rendered movie','duration_seconds':loaded.duration().to_seconds(),'video_clips':len(video),'audio_items':len(audio),'script_markers':len(marker_report),'linked_files_resolve':True,'intentional_new_recording_references':pending,'stock_clips_downloaded':0,'contacts':script['contacts']}
(ROOT/'Timeline_Validation.json').write_text(json.dumps(report,indent=2))
(ROOT/'timing_markers.json').write_text(json.dumps(marker_report,indent=2))
print(json.dumps(report,indent=2))

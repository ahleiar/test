from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import json,math,subprocess,textwrap
import numpy as np
ROOT=Path(__file__).resolve().parent
W,H,FPS=1920,1080,24
FONT='/usr/share/fonts/openai-sans/OpenAISans-Bold.woff2'
REG='/usr/share/fonts/openai-sans/OpenAISans-Medium.woff2'
BG=(7,10,14);WHITE=(250,252,248);LIME=(208,255,53);GRAY=(141,154,164)
CACHE={}
def f(n,regular=False):
 k=(n,regular)
 if k not in CACHE:CACHE[k]=ImageFont.truetype(REG if regular else FONT,n)
 return CACHE[k]
def ease(x):return 1-(1-max(0,min(1,x)))**3
def text(im,s,xy,size,color=WHITE,alpha=1,regular=False):
 if alpha<=0:return
 ImageDraw.Draw(im).text(xy,s,font=f(size,regular),anchor='lt',fill=(*color,round(255*alpha)))
def project(p):
 lon,lat=p;return (85+(lon+140)/220*1750,235+(80-lat)/135*640)
def make_map():
 base=Image.new('RGBA',(W,H),(*BG,255));d=ImageDraw.Draw(base)
 data=json.loads((ROOT/'countries.geojson').read_text())
 for item in data['features']:
  g=item['geometry'];polys=g['coordinates'] if g['type']=='MultiPolygon' else [g['coordinates']]
  code=item['properties'].get('ADM0_A3')
  color=(39,48,58) if code not in {'ZAF','IRL','USA'} else (61,75,83)
  for poly in polys:
   ring=poly[0]
   if max(abs(ring[i+1][0]-ring[i][0]) for i in range(len(ring)-1))>180:continue
   d.polygon([project(p) for p in ring],fill=(*color,255),outline=(69,82,93,255),width=1)
 return base
NODES=[(22.94,-30.56),(-8.0,53.4),(-90.1994,38.627)]
LABELS=['SOUTH AFRICA','IRELAND','ST. LOUIS']
EMPLOYERS=['FINE & RARE WINES','DM FINANCIAL','ABSTRAKT MARKETING GROUP']
def great_circle(a,b,n=180):
 def vec(p):
  lon,lat=np.radians(p);return np.array([np.cos(lat)*np.cos(lon),np.cos(lat)*np.sin(lon),np.sin(lat)])
 u=vec(a);v=vec(b);angle=np.arccos(np.clip(np.dot(u,v),-1,1));out=[]
 for t in np.linspace(0,1,n):
  q=(np.sin((1-t)*angle)*u+np.sin(t*angle)*v)/np.sin(angle)
  out.append(project((np.degrees(np.arctan2(q[1],q[0])),np.degrees(np.arctan2(q[2],np.hypot(q[0],q[1]))))))
 return out
PATHS=[great_circle(NODES[0],NODES[1]),great_circle(NODES[1],NODES[2])]
BASE=make_map()
def map_frame(t):
 im=BASE.copy();d=ImageDraw.Draw(im)
 text(im,'ACT 03 / EXPERIENCE',(98,58),28,LIME,regular=True)
 text(im,'ACROSS BORDERS.',(93,111+22*(1-ease(t/.5))),95,WHITE)
 progress=[ease((t-.7)/1.8),ease((t-2.9)/1.9)]
 active=0
 for i,p in enumerate(progress):
  if p>0:
   path=PATHS[i];count=max(2,round((len(path)-1)*p)+1)
   d.line(path[:count],fill=(*LIME,255),width=5,joint='curve')
   x,y=path[min(count-1,len(path)-1)]
   d.ellipse((x-7,y-7,x+7,y+7),fill=(*LIME,255))
  if p>=.999:active=i+1
 for i,node in enumerate(NODES):
  x,y=project(node);lit=i<=active
  color=LIME if lit else GRAY
  d.ellipse((x-5,y-5,x+5,y+5),fill=(*color,255))
  if lit:
   rad=12+5*(math.sin(t*2.5+i)*.5+.5)
   d.ellipse((x-rad,y-rad,x+rad,y+rad),outline=(*LIME,100),width=1)
  offsets=[(18,6),(18,-41),(18,-39)]
  dx,dy=offsets[i]
  text(im,LABELS[i],(x+dx,y+dy),29,color,regular=True)
 text(im,EMPLOYERS[active],(98,922),49,WHITE)
 text(im,'SOUTH AFRICA   →   IRELAND   →   ST. LOUIS',(100,1006),24,GRAY,regular=True)
 return im

def contact_frame(t):
 im=Image.new('RGBA',(W,H),(*BG,255))
 p=ease((t-.1)/.55);o=min(1,t/.2)
 text(im,'LET’S CONNECT.',(100,99),43,LIME,o)
 text(im,'ALEXANDER',(92,227+65*(1-p)),148,WHITE,o)
 text(im,'LEIAR',(92,382+65*(1-ease((t-.18)/.55))),148,WHITE,o)
 p2=ease((t-.6)/.45)
 text(im,'alexleiar@gmail.com',(101,638+28*(1-p2)),64,WHITE,p2)
 text(im,'linkedin.com/in/alex-leiar-395b1a415',(104,751+28*(1-p2)),43,GRAY,p2,True)
 text(im,'COMMERCIAL REAL ESTATE / ENTREPRENEURSHIP',(104,978),25,GRAY,p2,True)
 return im

def encode(path,duration,func):
 cmd=['ffmpeg','-v','error','-y','-f','rawvideo','-pix_fmt','rgba','-s',f'{W}x{H}','-r',str(FPS),'-i','-','-an','-c:v','libx264','-preset','fast','-crf','18','-threads','2','-pix_fmt','yuv420p','-movflags','+faststart',str(path)]
 p=subprocess.Popen(cmd,stdin=subprocess.PIPE)
 for i in range(round(duration*FPS)):p.stdin.write(func(i/FPS).convert('RGBA').tobytes())
 p.stdin.close()
 if p.wait():raise RuntimeError('Graphics render failed')
 subprocess.run(['ffmpeg','-v','error','-xerror','-i',str(path),'-f','null','-'],check=True)
 print('Rendered and decoded',path.name,flush=True)

def placeholders():
 s=json.loads((ROOT/'script.json').read_text());groups={}
 for act in s['acts']:
  for line in act['lines']:
   key=line['recording_slot']
   if key in {'R01A','R01B','R03A','R03B','R04','R05'}:groups.setdefault(key,[]).append(line['text'])
 out=ROOT/'recording_slots';out.mkdir(exist_ok=True)
 for key,paragraphs in groups.items():
  im=Image.new('RGBA',(W,H),(*BG,255));d=ImageDraw.Draw(im)
  text(im,'RECORDING REQUIRED / '+key,(100,92),37,LIME)
  text(im,'YOUR CAMERA TAKE GOES HERE' if key not in {'R03A','R03B'} else 'YOUR VOICE PICKUP GOES HERE',(96,186),71,WHITE)
  y=339
  for para in paragraphs:
   words=para.split();lines=[];buf=''
   for word in words:
    nxt=(buf+' '+word).strip()
    if d.textlength(nxt,font=f(39,True))>1680 and buf:lines.append(buf);buf=word
    else:buf=nxt
   if buf:lines.append(buf)
   for ln in lines:text(im,ln,(102,y),39,WHITE,regular=True);y+=56
   y+=25
  text(im,'TEMPORARY REVIEW SLOT — REPLACE WITH YOUR ORIGINAL RECORDING',(101,1002),25,GRAY,regular=True)
  im.convert('RGB').save(out/f'{key}.png')
 print('Saved clearly marked camera slots:',', '.join(groups),flush=True)


def travel_project(p):
 lon,lat=p;return (65+(lon+180)/360*1790,240+(85-lat)/150*640)
def travel_frame(t):
 import types
 global TRAVEL_BASE
 if 'TRAVEL_BASE' not in globals():TRAVEL_BASE=types.FunctionType(make_map.__code__,{**globals(),'project':travel_project})()
 im=TRAVEL_BASE.copy();d=ImageDraw.Draw(im)
 text(im,'ACT 02 / TRAVEL',(98,58),28,LIME,regular=True)
 text(im,'NEW PERSPECTIVES.',(93,111),95,WHITE)
 places=[('AFRICA',(20,0)),('EUROPE',(15,53)),('ASIA',(95,30))]
 active=min(2,int(t/2.1))
 for i,(name,p) in enumerate(places):
  x,y=travel_project(p);color=LIME if i==active else GRAY
  r=7 if i==active else 4;d.ellipse((x-r,y-r,x+r,y+r),fill=(*color,255))
  text(im,name,(x+17,y-17),31,color,regular=True)
 text(im,places[active][0],(95,918+25*(1-ease((t-active*2.1)/.4))),65,WHITE)
 text(im,'AFRICA   /   EUROPE   /   ASIA',(100,1006),24,GRAY,regular=True)
 return im

if __name__=='__main__':
 encode(ROOT/'Route_Motion_Preview.mp4',6.5,map_frame)
 encode(ROOT/'Travel_Map_Preview.mp4',6.3,travel_frame)
 encode(ROOT/'Contact_Card_Preview.mp4',5,contact_frame)
 placeholders()
 (ROOT/'MAP_CREDITS.md').write_text('# Map source\n\nCountry outlines: Natural Earth 1:110m Admin 0 Countries, public-domain dataset.\n\nSource: https://github.com/nvkelso/natural-earth-vector/blob/master/geojson/ne_110m_admin_0_countries.geojson\n\nPublic-domain statement: https://github.com/nvkelso/natural-earth-vector/blob/master/README.md\n\nThe route uses a country-level South Africa marker, a country-level Ireland marker, and the geographic position of St. Louis. It does not identify an employer’s exact office.\n')

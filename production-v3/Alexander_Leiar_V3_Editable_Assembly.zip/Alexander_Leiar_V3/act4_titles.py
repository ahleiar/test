from pathlib import Path
import sys,types
from PIL import Image
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT.parent))
import motion
for label,name in [('Adaptability','Adaptability'),('Relationships','Relationships'),('Global Perspective','Global_Perspective')]:
 def frame(t,label=label):
  im=Image.new('RGBA',(1920,1080));motion.lower(im,t,0,3,label);return im
 render=types.FunctionType(motion.render.__code__,{**motion.render.__globals__,'frame':frame},argdefs=motion.render.__defaults__)
 render(ROOT/f'Act4_{name}.mov',3)
